import React from 'react';

const ReviewsPage = () => {
    return (
        <div>
            this is review page coming soon
        </div>
    );
};

export default ReviewsPage;