import React from "react";

const ApplicantMessage = () => {
  return (
    <div className="text-2xl text-center">
      coming soon message if recruiter sent
    </div>
  );
};

export default ApplicantMessage;
