import { createSlice } from "@reduxjs/toolkit";
const initialState = {};
const blogPostSlice = createSlice({
  name: "blogPost",
  initialState,
  reducers: {},
});
export const {} = blogPostSlice.actions;
export default blogPostSlice.reducer;
